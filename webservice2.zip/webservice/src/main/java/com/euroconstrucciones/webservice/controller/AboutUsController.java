package com.euroconstrucciones.webservice.controller;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.springframework.core.io.Resource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.StreamUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Sobre nosotros", description = "Aquí obtendremos la descripción de la empresa")
@RestController
@RequestMapping("/aboutUs")
public class AboutUsController {

	@GetMapping(produces = "text/html; charset=UTF-8")
	@Operation(summary = "Obtiene el texto del fichero de descripción")
	public ResponseEntity<String> getAboutUsText() {
		try {
			String text = "";
			File textDir = new ClassPathResource("templates").getFile();
			File[] textDirFiles = textDir.listFiles();
			if (textDirFiles != null) {
				for (File file : textDirFiles) {
					if (file.getName().toLowerCase().contains("sobrenosotros")) {
						Resource textFile = new ClassPathResource("templates/" + file.getName());
						text = StreamUtils.copyToString(textFile.getInputStream(), StandardCharsets.UTF_8);
						break;
					}
				}
				//HttpHeaders headers = new HttpHeaders();
				//headers.add(HttpHeaders.CONTENT_TYPE, "text/html");
				return !text.isBlank() ? new ResponseEntity<>(text, HttpStatus.OK)
						: new ResponseEntity<>(HttpStatus.NOT_FOUND);
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (IOException e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
