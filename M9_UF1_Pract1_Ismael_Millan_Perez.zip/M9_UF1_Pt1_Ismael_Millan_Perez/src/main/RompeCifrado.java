package main;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class RompeCifrado {

	public static void main(String[] args) {
		byte[] mensajeCifrado = { (byte) 0xB3, (byte) 0xF9, (byte) 0xB2, (byte) 0x72, (byte) 0xA9, (byte) 0x07,
				(byte) 0x1F, (byte) 0xA4, (byte) 0x91, (byte) 0xA0, (byte) 0x1B, (byte) 0x48, (byte) 0x0D, (byte) 0x4F,
				(byte) 0xEC, (byte) 0xA0, (byte) 0x56, (byte) 0x54, (byte) 0x4A, (byte) 0xBB, (byte) 0x3C, (byte) 0xF1,
				(byte) 0xFF, (byte) 0x4F, (byte) 0xD0, (byte) 0x7F, (byte) 0xA6, (byte) 0x9B, (byte) 0x8F, (byte) 0x74,
				(byte) 0xF6, (byte) 0x8F };

		String mensajeIntegro = descifrado(mensajeCifrado);
		System.out.println(mensajeIntegro);
	}

	public static String descifrarMensaje(SecretKey sKey, byte[] mensaje) {
		byte[] encriptado = null;
		try {

			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");

			cipher.init(Cipher.DECRYPT_MODE, sKey);
			encriptado = cipher.doFinal(mensaje);
		} catch (Exception e) {
			return null;
		}

		return new String(encriptado, StandardCharsets.UTF_8);
	}

	public static String descifrado(byte[] mensaje) {
		String mensajeDescifrado = "";
		int keySize = 256;
		try {
			for (int i = 0; i < 100000; i++) {
				MessageDigest messDig = MessageDigest.getInstance("SHA-256");
				System.out.println(i + ". Waiting for message...");
				String passwdString = String.format("%05d", i);
				byte[] hashPasswd = messDig.digest(passwdString.getBytes());

				SecretKeySpec clave = new SecretKeySpec(Arrays.copyOf(hashPasswd, keySize / 8), "AES");

				mensajeDescifrado = descifrarMensaje(clave, mensaje);

				if (mensajeDescifrado != null && mensajeDescifrado.matches("[\\p{Print}]+")) {
					break;
				}
			}
		} catch (Exception e) {
			return null;
		}
		return mensajeDescifrado;
	}

}
