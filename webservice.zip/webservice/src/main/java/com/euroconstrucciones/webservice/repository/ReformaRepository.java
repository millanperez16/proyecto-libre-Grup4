package com.euroconstrucciones.webservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.euroconstrucciones.webservice.domain.Reforma;

public interface ReformaRepository extends JpaRepository <Reforma, Long>{

}
