package com.euroconstrucciones.webservice.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import com.euroconstrucciones.webservice.domain.Reforma;
import com.euroconstrucciones.webservice.repository.ReformaRepository;
import com.euroconstrucciones.webservice.service.ReformaService;

@Validated
@Service
public class ReformaServiceImpl implements ReformaService {

	@Autowired
	private ReformaRepository reformaRepository;
	
	@Override
	public Iterable<Reforma> findAll() {
		return reformaRepository.findAll();
	}

	@Override
	public Page<Reforma> findAll(Pageable pageable) {
		return reformaRepository.findAll(pageable);
	}

	@Override
	public Reforma findById(Long id) {
		Optional<Reforma> reforma = reformaRepository.findById(id);
		if (reforma.isEmpty()) {
			return null;
		}
		return reforma.get();
	}

	@Override
	public Reforma save(Reforma reforma) {
		return reformaRepository.save(reforma);
	}
	
	@Override
	public Reforma update(Reforma reformaUpdate) {
		Optional<Reforma> updateReforma = reformaRepository.findById(reformaUpdate.getIdPresupuesto());
		Reforma reforma = updateReforma.get();
		return reformaRepository.save(reforma);
	}

	@Override
	public void deleteById(Long id) {
		reformaRepository.deleteById(id);
	}

}
