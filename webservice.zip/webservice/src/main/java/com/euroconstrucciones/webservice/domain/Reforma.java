package com.euroconstrucciones.webservice.domain;

import com.euroconstrucciones.webservice.validators.groups.AseosValidations;
import com.euroconstrucciones.webservice.validators.groups.CocinaValidations;

import jakarta.persistence.Entity;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Reforma extends Presupuesto {

	public static final String PREFIJO = "RE";
	public static final int MANO_DE_OBRA = 50;
	public static final int PRECIO_M2 = 35;
	
	@NotNull(message="{validaciones.numbers.NotNull}", groups = {AseosValidations.class, CocinaValidations.class})
	@Positive(message="{validaciones.numbers.Positive}", groups = {AseosValidations.class, CocinaValidations.class})
	@Getter
	@Setter
	protected Float largo;
	
	@NotNull(message="{validaciones.numbers.NotNull}", groups = {AseosValidations.class, CocinaValidations.class})
	@Positive(message="{validaciones.numbers.Positive}", groups = {AseosValidations.class, CocinaValidations.class})
	@Getter
	@Setter
	protected Float ancho;
	
	@NotNull(message="{validaciones.numbers.NotNull}", groups = {AseosValidations.class, CocinaValidations.class})
	@Positive(message="{validaciones.numbers.Positive}", groups = {AseosValidations.class, CocinaValidations.class})
	@Getter
	@Setter
	protected Float alto;
	
	@NotNull(message="{validaciones.numbers.NotNull}", groups = {AseosValidations.class, CocinaValidations.class})
	@Positive(message="{validaciones.numbers.Positive}", groups = {AseosValidations.class, CocinaValidations.class})
	@Getter
	@Setter
	protected Float precioAzulejoM2;
	
	@NotNull(message="{validaciones.numbers.NotNull}", groups = {AseosValidations.class, CocinaValidations.class})
	@Getter
	@Setter
	protected Integer modifInstalacion;
	
	public Reforma(long idPresupuesto, Cliente cliente, double total, Float largo, Float ancho, Float alto,
			Float precio_azulejo_m2, Integer modif_instalacion) {
		super(idPresupuesto, cliente, total);
		this.largo = largo;
		this.ancho = ancho;
		this.alto = alto;
		this.precioAzulejoM2 = precio_azulejo_m2;
		this.modifInstalacion = modif_instalacion;
	}
}
