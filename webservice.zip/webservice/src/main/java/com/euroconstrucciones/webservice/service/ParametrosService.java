package com.euroconstrucciones.webservice.service;

import com.euroconstrucciones.webservice.domain.Parametros;

public interface ParametrosService {
	public void inicializarParametros();

	public void save(Parametros parametros);
	
	public String obtenerPrefijoObra();
    
    public String obtenerPrefijoReforma();
    
    public String obtenerSufijoAseo();
    
    public String obtenerSufijoCocina();
    
	public int obtenerPrecioObra();
    
	public int obtenerManoObraReforma();
    
	public int obtenerPrecioReforma();
    
	public double obtenerIva();
}
