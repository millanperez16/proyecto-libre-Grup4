package com.euroconstrucciones.webservice.details;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.euroconstrucciones.webservice.domain.Cliente;
import com.euroconstrucciones.webservice.repository.ClienteRepository;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {
	
	@Autowired
	private ClienteRepository clienteRepository;

	@Override
    public UserDetails loadUserByUsername(String username) {
        Cliente cliente = clienteRepository.findByCorreo(username);
        if (cliente == null) {
            throw new UsernameNotFoundException(username);
        }
        return cliente;
    }
}