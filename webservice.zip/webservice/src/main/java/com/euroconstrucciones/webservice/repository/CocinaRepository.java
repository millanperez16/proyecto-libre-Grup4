package com.euroconstrucciones.webservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.euroconstrucciones.webservice.domain.Cocina;

public interface CocinaRepository extends JpaRepository<Cocina, Long> {

}
