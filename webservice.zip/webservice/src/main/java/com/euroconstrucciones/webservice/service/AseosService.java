package com.euroconstrucciones.webservice.service;

import org.springframework.data.domain.Page;

import com.euroconstrucciones.webservice.domain.Aseos;

public interface AseosService {
	public Iterable<Aseos> findAll();

	public Page<Aseos> findAll(int pagina);

	public Aseos findById(Long id);
	
	public Aseos save(Aseos aseos);
	
	public Aseos update(Aseos aseosUpdate);

	public void deleteById(Long id);
}
