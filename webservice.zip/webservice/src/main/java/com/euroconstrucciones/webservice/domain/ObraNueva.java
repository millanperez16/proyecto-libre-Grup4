package com.euroconstrucciones.webservice.domain;

import com.euroconstrucciones.webservice.validators.groups.ObraNuevaValidations;

import jakarta.persistence.Entity;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Entity
public class ObraNueva extends Presupuesto {
	
	public static final String PREFIJO = "OBN";
	public static final int PRECIO_M2 = 1100;
		
	@NotNull(message="{validaciones.numbers.NotNull}", groups = ObraNuevaValidations.class)
	@Positive(message="{validaciones.numbers.Positive}", groups = ObraNuevaValidations.class)
	@Getter
	@Setter
	private Integer superficie;
	
	@NotNull(message="{validaciones.numbers.radiobutton.NotNull}", groups = ObraNuevaValidations.class)
	@Getter
	@Setter
	private Double calidad;

	public ObraNueva(long id_presupuesto, Cliente cliente, double total, Integer superficie, Double calidad) {
		super(id_presupuesto, cliente, total);
		this.superficie = superficie;
		this.calidad = calidad;
	}

}
