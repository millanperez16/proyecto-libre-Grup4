package com.euroconstrucciones.webservice.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
//import org.springframework.validation.annotation.Validated;
import org.springframework.validation.annotation.Validated;

import com.euroconstrucciones.webservice.domain.ObraNueva;
import com.euroconstrucciones.webservice.repository.ObraNuevaRepository;
import com.euroconstrucciones.webservice.service.ObraNuevaService;
import com.euroconstrucciones.webservice.validators.groups.ObraNuevaValidations;

//@Validated
@Service
public class ObraNuevaServiceImpl implements ObraNuevaService {
	@Autowired
	private ObraNuevaRepository obraNuevaRepository;

	@Override
	public Iterable<ObraNueva> findAll() {
		return obraNuevaRepository.findAll();
	}

	@Override
	public Page<ObraNueva> findAll(int pagina) {
		int tamano = 5;
	     
	    Pageable pageable = PageRequest.of(pagina - 1, tamano);
	     
		return obraNuevaRepository.findAll(pageable);
	}

	@Override
	public ObraNueva findById(Long id) {
		Optional<ObraNueva> obranueva = obraNuevaRepository.findById(id);
		if (obranueva.isEmpty()) {
			return null;
		}
		return obranueva.get();
	}

	@Override
	public ObraNueva save(@Validated(ObraNuevaValidations.class) ObraNueva obranueva) {
		return obraNuevaRepository.save(obranueva);
	}
	
	@Override
	public ObraNueva update(ObraNueva obraNuevaUpdate) {
		return obraNuevaRepository.save(obraNuevaUpdate);
	}

	@Override
	public void deleteById(Long id) {
		obraNuevaRepository.deleteById(id);
	}
	
}

