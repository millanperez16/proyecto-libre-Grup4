package com.euroconstrucciones.webservice.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.euroconstrucciones.webservice.domain.Cliente;
import com.euroconstrucciones.webservice.domain.Rol;
import com.euroconstrucciones.webservice.repository.ClienteRepository;
import com.euroconstrucciones.webservice.repository.RolRepository;
import com.euroconstrucciones.webservice.service.ClienteService;
import com.euroconstrucciones.webservice.token.JwtService;

import jakarta.validation.constraints.NotEmpty;

@Service
public class ClienteServiceImpl implements ClienteService {

	@Autowired
	private ClienteRepository clienteRepository;

	@Autowired
	private RolRepository rolRepository;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	@Autowired
	private JwtService jwtProvider;
	
	@Override
	public List<Cliente> findAll() {
		return clienteRepository.findAll();
	}

	@Override
	public Page<Cliente> findAll(int pagina) {
		int tamano = 15;
		
		Pageable pageable = PageRequest.of(pagina - 1, tamano);
		
		return clienteRepository.findAll(pageable);
	}

	@Override
	public Cliente findById(Long id) {
		Optional<Cliente> cliente = clienteRepository.findById(id);
		if (cliente.isEmpty()) {
			return null;
		}
		return cliente.get();
	}
	
	@Override
	public String authenticate(@NotEmpty String correo, @NotEmpty String passwd) {
        Cliente cliente = clienteRepository.findByCorreo(correo);

        if (cliente != null && passwordEncoder.matches(passwd, cliente.getPassword())) {
            String token = jwtProvider.generateToken(cliente);
            return token;
        } else {
            return null;
        }
	}

	@Override
	public Cliente save(Cliente cliente) {
		Rol roleUser = rolRepository.findByNombre("ROLE_USER");
		Rol roleAdmin = rolRepository.findByNombre("ROLE_ADMIN");
		
		if (roleUser == null && roleAdmin == null) {
			roleAdmin = rolRepository.save(new Rol("ROLE_ADMIN"));
			roleUser = rolRepository.save(new Rol("ROLE_USER"));
		}

		if (clienteRepository.count() == 0) {
			cliente.setRol(roleAdmin);
		} else {
			cliente.setRol(roleUser);
		}
		
		passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(cliente.getPasswd());
		cliente.setPasswd(encodedPassword);
		
		return clienteRepository.save(cliente);
	}
	
	@Override
	public Cliente update(Cliente cliente) {
		passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(cliente.getPasswd());
		cliente.setPasswd(encodedPassword);
		
		return clienteRepository.save(cliente);
	}

	@Override
	public void deleteById(Long id) {
		clienteRepository.deleteById(id);
	}

	@Override
	public boolean existsUsuarioPorCorreo(String correo) {
		return clienteRepository.existsByCorreo(correo);
	}

	@Override
	public Cliente findByCorreo(String correo) {
		return clienteRepository.findByCorreo(correo);
	}

}