package com.euroconstrucciones.webservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.euroconstrucciones.webservice.domain.Parametros;

public interface ParametrosRepository extends JpaRepository<Parametros, Long>{
    
    @Query("SELECT p.prefijoObra FROM Parametros p")
    String obtenerPrefijoObra();
    
    @Query("SELECT p.prefijoReforma FROM Parametros p")
    String obtenerPrefijoReforma();
    
    @Query("SELECT p.sufijoAseo FROM Parametros p")
    String obtenerSufijoAseo();
    
    @Query("SELECT p.sufijoCocina FROM Parametros p")
    String obtenerSufijoCocina();
    
    @Query("SELECT p.precioM2Obra FROM Parametros p")
    int obtenerPrecioObra();
    
    @Query("SELECT p.manoDeObraReforma FROM Parametros p")
    int obtenerManoObraReforma();
    
    @Query("SELECT p.precioM2Reforma FROM Parametros p")
    int obtenerPrecioReforma();
    
	// Método para obtener el valor del IVA
    @Query("SELECT p.IVA FROM Parametros p")
    double obtenerIva();
}
