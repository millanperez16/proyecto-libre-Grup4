package com.euroconstrucciones.webservice.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Entity
public class Parametros {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Getter
	private long id;
	
	@Getter @Setter public String prefijoObra;
	@Getter @Setter public String prefijoReforma;
	@Getter @Setter public String sufijoAseo;
	@Getter @Setter public String sufijoCocina;
	
	@Column(name = "precio_m2_obra")
	@Getter @Setter public int precioM2Obra;
	@Getter @Setter public int manoDeObraReforma;
	@Column(name = "precio_m2_reforma")
	@Getter @Setter public int precioM2Reforma;
	@Getter @Setter public double IVA;
}
