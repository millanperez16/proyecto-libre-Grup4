package com.euroconstrucciones.webservice.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Galería", description = "Aquí obtendremos las imágenes")
@RestController
@RequestMapping("/images")
public class GalleryController {
	
	@GetMapping
	@Operation(summary = "Obtiene una lista con los nombres de las imágenes ")
	public ResponseEntity<List<String>> listImages() {
		try {
			File imgDir = new ClassPathResource("static/images").getFile();
			File[] imgFiles = imgDir.listFiles();
			if (imgFiles != null) {
				List<String> imageNames = new ArrayList<>();
				for (File imgFile : imgFiles) {
					if (imgFile.isFile()) {
						imageNames.add(imgFile.getName());
					}
				}
				return new ResponseEntity<>(imageNames, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
		} catch (IOException e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/{imageName}")
	public ResponseEntity<byte[]> getImage(@PathVariable String imageName) {
		try {
			Resource imgFile = new ClassPathResource("static/images/" + imageName);
			byte[] bytes = StreamUtils.copyToByteArray(imgFile.getInputStream());

			HttpHeaders headers = new HttpHeaders();
			headers.add(HttpHeaders.CONTENT_TYPE, "image/jpeg");

			return new ResponseEntity<>(bytes, headers, HttpStatus.OK);
		} catch (IOException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
}
