package com.euroconstrucciones.webservice.domain;

import java.util.Date;

import com.euroconstrucciones.webservice.validators.groups.PresupuestoValidations;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="presupuestos")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Presupuesto {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Getter
	protected long idPresupuesto;
	
	@ManyToOne
    @JoinColumn(name = "cliente", referencedColumnName = "idCliente")
	@Getter
	@Setter
	protected Cliente cliente;

	@Getter
	@Setter
	protected String referencia;
	
	@NotEmpty(message="{validaciones.strings.NotEmpty}", groups = PresupuestoValidations.class)
	@Getter
	@Setter
	protected String destinatario;
	
	@NotEmpty(message="{validaciones.strings.NotEmpty}", groups = PresupuestoValidations.class)
	@Getter
	@Setter
	protected String direccion;
	
	@NotEmpty(message="{validaciones.strings.NotEmpty}", groups = PresupuestoValidations.class)
	@Getter
	@Setter
	protected String codigoPostal;
	
	@NotEmpty(message="{validaciones.strings.NotEmpty}", groups = PresupuestoValidations.class)
	@Getter
	@Setter
	protected String municipio;
	
	@NotEmpty(message="{validaciones.strings.NotEmpty}", groups = PresupuestoValidations.class)
	@Getter
	@Setter
	protected String provincia;
	
	//@NotEmpty(message="{validaciones.strings.NotEmpty}", groups = PresupuestoValidations.class)
	@Getter
	@Setter
	protected String comunidad;
	
	//@NotEmpty(message="{validaciones.strings.NotEmpty}", groups = PresupuestoValidations.class)
	@Getter
	@Setter
	protected String pais;
	
	@Column(name = "fecha", nullable = false, updatable = false, insertable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@Getter
	@Setter
	protected Date fecha;

	@Getter
	@Setter
	protected double total;
	
	public Presupuesto(long id_presupuesto, Cliente cliente, double total) {
		super();
		this.idPresupuesto = id_presupuesto;
		this.cliente = cliente;
		this.total = total;
	}
		
}