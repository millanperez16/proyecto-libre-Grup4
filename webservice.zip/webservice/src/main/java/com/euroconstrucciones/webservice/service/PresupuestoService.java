package com.euroconstrucciones.webservice.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.euroconstrucciones.webservice.domain.Cliente;
import com.euroconstrucciones.webservice.domain.Presupuesto;

public interface PresupuestoService {

	public Iterable<Presupuesto> findAll();

	public Page<Presupuesto> findAll(int pagina);

	public Presupuesto findById(Long id);
	
	public List<Presupuesto> findByCliente (Cliente cliente);
	
	public Page<Presupuesto> findPresupuestoByCliente(Cliente iniciado, int pagina);

	public Presupuesto save(Presupuesto presupuesto);
	
	public Presupuesto update(Presupuesto presupuestoUpdate);

	public void deleteById(Long id);
	
	public int countAllPresupuesto();

}
