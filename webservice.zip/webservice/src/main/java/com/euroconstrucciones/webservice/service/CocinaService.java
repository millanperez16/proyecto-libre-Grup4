package com.euroconstrucciones.webservice.service;

import org.springframework.data.domain.Page;

import com.euroconstrucciones.webservice.domain.Cocina;

public interface CocinaService {
	public Iterable<Cocina> findAll();

	public Page<Cocina> findAll(int pagina);

	public Cocina findById(Long id);
	
	public Cocina save(Cocina cocina);
	
	public Cocina update(Cocina aseosUpdate);

	public void deleteById(Long id);
}
