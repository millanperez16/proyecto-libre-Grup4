package com.euroconstrucciones.webservice.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.euroconstrucciones.webservice.domain.Cliente;
import com.euroconstrucciones.webservice.domain.Cocina;
import com.euroconstrucciones.webservice.service.ClienteService;
import com.euroconstrucciones.webservice.service.CocinaService;
import com.euroconstrucciones.webservice.service.ParametrosService;
import com.euroconstrucciones.webservice.service.PresupuestoService;
import com.euroconstrucciones.webservice.token.JwtService;
import com.euroconstrucciones.webservice.validators.groups.CocinaValidations;
import com.euroconstrucciones.webservice.validators.groups.PresupuestoValidations;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Cocina", description = "CocinaController API")
@RestController
@SecurityRequirement(name = "Bearer Authentication")
@RequestMapping("/presupuestos/cocina")
public class CocinaController {
	
	@Autowired
	private CocinaService cocinaService;
	
	@Autowired
	private ClienteService clienteService;

	@Autowired
	private PresupuestoService presupuestoService;
	
	@Autowired
	private JwtService jwtService;
	
	@Autowired
	private ParametrosService paramService;
	
	private LocalDate fechas = LocalDate.now();

	private String annio = Integer.toString(fechas.getYear());
	private String mes = String.format("%02d", fechas.getMonthValue());
	private String dia = String.format("%02d", fechas.getDayOfMonth());
	
	@GetMapping("/findAllRefCocina")
	@Operation(summary = "Encuentra todas las reformas de cocina")
	public List<Cocina> findAllRefCocina(@RequestParam int pagina) {
		return cocinaService.findAll(pagina).getContent();
	}
	@PostMapping("/saveRefCocina")
	@Operation(summary = "Guarda un presupuesto de una reforma de cocina")
	public Cocina saveRefCocina(@RequestHeader("Authorization") String authHeader,
			@RequestBody @Validated({ CocinaValidations.class, PresupuestoValidations.class }) Cocina cocina) {
	    String token = authHeader.substring(7);
	    String correo = jwtService.extractUsername(token);
	    Cliente cliente = clienteService.findByCorreo(correo);
	    
	    cocina.setCliente(cliente);
		cocina.setReferencia(paramService.obtenerPrefijoReforma() + annio + mes + dia + String.format("%07d", presupuestoService.countAllPresupuesto() + 1) + paramService.obtenerSufijoCocina());
		cocina.setTotal((2 * (cocina.getLargo() + cocina.getAncho()) * cocina.getAlto()
				+ (cocina.getAncho() * cocina.getLargo()) * paramService.obtenerManoObraReforma() + cocina.getPrecioAzulejoM2()
				+ (cocina.getAncho() * cocina.getLargo()) * paramService.obtenerPrecioReforma() + (cocina.getMuebleMtrLineales() * 80)
				+ (cocina.getEncimeraMtrLineales() * 150) + cocina.getModifInstalacion()) * paramService.obtenerIva());
		return cocinaService.save(cocina);
	}
	
	@PutMapping("/updateRefCocina")
	@Operation(summary = "Actualiza los datos de un presupuesto de una reforma de cocina")
	public Cocina updateRefCocina(
			@RequestBody @Validated({ CocinaValidations.class, PresupuestoValidations.class }) Cocina cocina) {
		cocina.setTotal((2 * (cocina.getLargo() + cocina.getAncho()) * cocina.getAlto()
				+ (cocina.getAncho() * cocina.getLargo()) * paramService.obtenerManoObraReforma() + cocina.getPrecioAzulejoM2()
				+ (cocina.getAncho() * cocina.getLargo()) * paramService.obtenerPrecioReforma() + (cocina.getMuebleMtrLineales() * 80)
				+ (cocina.getEncimeraMtrLineales() * 150) + cocina.getModifInstalacion()) * paramService.obtenerIva());
		return cocinaService.update(cocina);
	}
}
