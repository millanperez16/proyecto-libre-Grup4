package com.euroconstrucciones.webservice.domain;

import com.euroconstrucciones.webservice.validators.groups.AseosValidations;
import com.euroconstrucciones.webservice.validators.groups.CocinaValidations;

import jakarta.persistence.Entity;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Cocina extends Reforma {
	
	public static final String SUFIJO = "CO";
	
	@NotNull(message="{validaciones.numbers.NotNull}", groups = CocinaValidations.class)
	@Positive(message="{validaciones.numbers.Positive}", groups = AseosValidations.class)
	@Getter
	@Setter
	private Integer muebleMtrLineales;
	
	@NotNull(message="{validaciones.numbers.NotNull}", groups = CocinaValidations.class)
	@Positive(message="{validaciones.numbers.Positive}", groups = AseosValidations.class)
	@Getter
	@Setter
	private Integer encimeraMtrLineales;
	
	public Cocina(long id_presupuesto, Cliente cliente, double total, float largo, float ancho, float alto,
			float precio_azulejo_m2, int modif_instalacion, Integer muebleMtrLineales, Integer encimeraMtrLineales) {
		super(id_presupuesto, cliente, total, largo, ancho, alto, precio_azulejo_m2, modif_instalacion);
		this.muebleMtrLineales = muebleMtrLineales;
		this.encimeraMtrLineales = encimeraMtrLineales;
	}

}
