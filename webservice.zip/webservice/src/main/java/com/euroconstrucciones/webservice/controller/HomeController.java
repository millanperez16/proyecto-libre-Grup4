package com.euroconstrucciones.webservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Bienvenida", description = "Getter de bienvenida")
@RestController
public class HomeController {

	@GetMapping("/")
	public String home() {
		return "Bienvenido a la página de Presupuestos!!";
	}
}
