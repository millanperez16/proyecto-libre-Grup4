package com.euroconstrucciones.webservice.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.euroconstrucciones.webservice.domain.Aseos;
import com.euroconstrucciones.webservice.domain.Cliente;
import com.euroconstrucciones.webservice.service.AseosService;
import com.euroconstrucciones.webservice.service.ClienteService;
import com.euroconstrucciones.webservice.service.ParametrosService;
import com.euroconstrucciones.webservice.service.PresupuestoService;
import com.euroconstrucciones.webservice.token.JwtService;
import com.euroconstrucciones.webservice.validators.groups.AseosValidations;
import com.euroconstrucciones.webservice.validators.groups.PresupuestoValidations;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Aseos", description = "AseosController API")
@RestController
@SecurityRequirement(name = "Bearer Authentication")
@RequestMapping("/presupuestos/aseos")
public class AseosController {
	
	@Autowired
	private AseosService aseosService;
	
	@Autowired
	private ClienteService clienteService;
	
	@Autowired
	private PresupuestoService presupuestoService;
	
	@Autowired
	private JwtService jwtService;
	
	@Autowired
	private ParametrosService paramService;
	
	private LocalDate fechas = LocalDate.now();

	private String annio = Integer.toString(fechas.getYear());
	private String mes = String.format("%02d", fechas.getMonthValue());
	private String dia = String.format("%02d", fechas.getDayOfMonth());
	
	@GetMapping("/findAllRefAseos")
	@Operation(summary = "Encuentra todas las reformas de aseos")
	public List<Aseos> findAllRefAseos(@RequestParam int pagina) {
		return aseosService.findAll(pagina).getContent();
	}
	
	@PostMapping("/saveRefAseo")
	@Operation(summary = "Guarda un presupuesto de una reforma de aseo")
	public Aseos saveRefAseo(@RequestHeader("Authorization") String authHeader,
			@RequestBody @Validated({ AseosValidations.class, PresupuestoValidations.class }) Aseos aseos) {
	    String token = authHeader.substring(7);
	    String correo = jwtService.extractUsername(token);
	    Cliente cliente = clienteService.findByCorreo(correo);
	    
	    aseos.setCliente(cliente);
		aseos.setReferencia(paramService.obtenerPrefijoReforma() + annio + mes + dia + String.format("%07d", presupuestoService.countAllPresupuesto() + 1) + paramService.obtenerSufijoAseo());
		aseos.setTotal((2 * (aseos.getLargo() + aseos.getAncho()) * aseos.getAlto()
				+ (aseos.getAncho() * aseos.getLargo()) * paramService.obtenerManoObraReforma() + aseos.getPrecioAzulejoM2()
				+ (aseos.getAncho() * aseos.getLargo()) * paramService.obtenerPrecioReforma() + aseos.getNumSanitarios()
				+ aseos.getModifInstalacion()) * paramService.obtenerIva());
		return aseosService.save(aseos);
	}
	
	@PutMapping("/updateRefAseo")
	@Operation(summary = "Actualiza los datos de un presupuesto de una reforma de aseo")
	public Aseos updateRefAseo(
			@RequestBody @Validated({ AseosValidations.class, PresupuestoValidations.class }) Aseos aseos) {
		aseos.setTotal((2 * (aseos.getLargo() + aseos.getAncho()) * aseos.getAlto()
				+ (aseos.getAncho() * aseos.getLargo()) * paramService.obtenerManoObraReforma() + aseos.getPrecioAzulejoM2()
				+ (aseos.getAncho() * aseos.getLargo()) * paramService.obtenerPrecioReforma() + aseos.getNumSanitarios()
				+ aseos.getModifInstalacion()) * paramService.obtenerIva());
		return aseosService.update(aseos);
	}
	
}
