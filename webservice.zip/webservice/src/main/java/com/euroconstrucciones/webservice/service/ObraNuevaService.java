package com.euroconstrucciones.webservice.service;

import org.springframework.data.domain.Page;

import com.euroconstrucciones.webservice.domain.ObraNueva;

public interface ObraNuevaService {
	public Iterable<ObraNueva> findAll();

	public Page<ObraNueva> findAll(int pagina);

	public ObraNueva findById(Long id);

	public ObraNueva save(ObraNueva obraNueva);
	
	public ObraNueva update(ObraNueva obraNuevaUpdate);

	public void deleteById(Long id);

}
