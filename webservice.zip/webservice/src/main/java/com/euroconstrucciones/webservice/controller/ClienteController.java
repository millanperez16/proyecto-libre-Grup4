package com.euroconstrucciones.webservice.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.euroconstrucciones.webservice.domain.Cliente;
import com.euroconstrucciones.webservice.service.ClienteService;
import com.euroconstrucciones.webservice.token.ClienteToken;
import com.euroconstrucciones.webservice.token.JwtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

/* Swagger */
@Tag(name = "Cliente", description = "ClienteController API")
@RestController
@RequestMapping("/clientes")
public class ClienteController {
	
	@Autowired
	private ClienteService clienteService;
	
	@Autowired
	private JwtService jwtService;
	
	@GetMapping("/findAll")
	@Operation(summary = "Encuentra todos los clientes registrados")
	public List<Cliente> getAllClientes (@RequestParam int pagina) {
		return clienteService.findAll(pagina).getContent();
	}
	
	@GetMapping("/findById/{id}")
	@Operation(summary = "Encuentra un cliente por su id")
	public Cliente findById(@PathVariable Long id) {
		return clienteService.findById(id);
	}
	
	@GetMapping("/findByCorreo/{correo}")
	@Operation(summary = "Encuentra un cliente por su correo")
	public Cliente findByCorreo(@PathVariable String correo) {
		return clienteService.findByCorreo(correo);
	}
	
	//Hacer método authenticate
	@PostMapping("/authenticate")
	@Operation(summary = "Identifícate como usuario")
	@io.swagger.v3.oas.annotations.parameters.RequestBody(content = {
			@Content(mediaType = "application/json", examples = {
					@ExampleObject(value = "{\"correo\":\"string\",\"passwd\":\"string\"}") }) })
	public ResponseEntity<ClienteToken> authenticate(@RequestBody Map<String, String> correoPasswd) {
		if (correoPasswd != null) {
			Cliente cliente = clienteService.findByCorreo(correoPasswd.get("correo"));
			String token = clienteService.authenticate(correoPasswd.get("correo"),correoPasswd.get("passwd"));
			ClienteToken tokenCliente = new ClienteToken(cliente.getIdCliente(), token);
			if (jwtService.isTokenValid(token, cliente)) {
				return ResponseEntity.ok().body(tokenCliente);
			} else {
				return null;
			}
		} else {
			return null;
		}
	}
	
	@PostMapping("/save")
	@Operation(summary = "Guarda los datos de un cliente")
	public Cliente save(@RequestBody @Valid Cliente cliente) {
		return clienteService.save(cliente);
	}
	
	@PutMapping("/update")
	@Operation(summary = "Actualiza los datos de un cliente")
	public Cliente update(@RequestBody @Valid Cliente cliente) {
		return clienteService.update(cliente);
	}
	
	@DeleteMapping("/deleteById/{id}")
	@Operation(summary = "Elimina un cliente")
	public void deleteById(@PathVariable("id") Long id) {
		clienteService.deleteById(id);
	}
}
