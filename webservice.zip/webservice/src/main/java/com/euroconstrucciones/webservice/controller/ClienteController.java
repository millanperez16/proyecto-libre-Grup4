package com.euroconstrucciones.webservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.euroconstrucciones.webservice.domain.Cliente;
import com.euroconstrucciones.webservice.service.ClienteService;

import io.swagger.v3.oas.annotations.tags.Tag;

/* Swagger */
@Tag(name = "Cliente", description = "ClienteController API")
@RestController
@RequestMapping("/clientes")
public class ClienteController {
	
	@Autowired
	private ClienteService clienteService;

	@GetMapping("/")
	public String home() {
		return "Aquí se gestionan los clientes, no los presupuestos!! :(";
	}
	
	@GetMapping("/all")
	public List<Cliente> getAllClientes () {
		return (List<Cliente>) clienteService.findAll();
	}
	
	@GetMapping("/findById/{id}")
	public Cliente findById(@PathVariable Long id) {
		return clienteService.findById(id);
	}
}
