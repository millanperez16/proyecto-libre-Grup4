package com.euroconstrucciones.webservice.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.euroconstrucciones.webservice.domain.Reforma;

public interface ReformaService {

	public Iterable<Reforma> findAll();

	public Page<Reforma> findAll(Pageable pageable);

	public Reforma findById(Long id);
	
	public Reforma save(Reforma reforma);
	
	public Reforma update(Reforma reformaUpdate);

	public void deleteById(Long id);
}
