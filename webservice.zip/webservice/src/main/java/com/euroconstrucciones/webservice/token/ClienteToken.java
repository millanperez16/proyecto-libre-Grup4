package com.euroconstrucciones.webservice.token;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
public class ClienteToken {
	
	@Getter	@Setter
	private Long idCliente;

	@Getter	@Setter
	private String token;
}
