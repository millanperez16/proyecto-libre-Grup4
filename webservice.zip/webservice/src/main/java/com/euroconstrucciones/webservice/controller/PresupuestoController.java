package com.euroconstrucciones.webservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.tags.Tag;

/* Swagger */
@Tag(name = "Presupuesto", description = "PresupuestoController API")
@RestController
@RequestMapping("/presupuestos")
public class PresupuestoController {

	@GetMapping("/")
	public String home() {
		return "Aquí se gestionan los presupuestos!!";
	}
}
