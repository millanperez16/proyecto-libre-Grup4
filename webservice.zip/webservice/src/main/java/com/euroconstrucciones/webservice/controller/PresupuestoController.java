package com.euroconstrucciones.webservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.euroconstrucciones.webservice.domain.Cliente;
import com.euroconstrucciones.webservice.domain.Parametros;
import com.euroconstrucciones.webservice.domain.Presupuesto;
import com.euroconstrucciones.webservice.service.ClienteService;
import com.euroconstrucciones.webservice.service.ParametrosService;
import com.euroconstrucciones.webservice.service.PresupuestoService;
import com.euroconstrucciones.webservice.token.JwtService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;

/* Swagger */
@Tag(name = "Presupuesto", description = "PresupuestoController API")
@RestController
@SecurityRequirement(name = "Bearer Authentication")
@RequestMapping("/presupuestos")
public class PresupuestoController {
	
	@Autowired
	private ClienteService clienteService;
	
	@Autowired
	private PresupuestoService presupuestoService;
	
	@Autowired
	private ParametrosService paramService;
	
	@Autowired
	private JwtService jwtService;
	
	@GetMapping("/init")
	@Operation(summary = "Inicializa los parámetros y precios en base de datos")
	public void initializeParametros() {
		Parametros parametros = new Parametros();
		parametros.setPrefijoObra("OBN");
		parametros.setPrefijoReforma("RE");
		parametros.setSufijoAseo("A");
		parametros.setSufijoCocina("CO");
		parametros.setPrecioM2Obra(1100);
		parametros.setManoDeObraReforma(50);
		parametros.setPrecioM2Reforma(35);
		parametros.setIVA(1.21);
		paramService.save(parametros);
	}

	@GetMapping("/findAll")
	@Operation(summary = "Encuentra todos los presupuestos")
	public List<Presupuesto> findAll (@RequestParam int pagina) {
		return presupuestoService.findAll(pagina).getContent();
	}
	
	@GetMapping("/findById/{id}")
	@Operation(summary = "Encuentra un presupuesto por su id")
	public Presupuesto findById(@PathVariable Long id) {
		return presupuestoService.findById(id);
	}
	
	@GetMapping("/findByCliente/{correo}")
	@Operation(summary = "Encuentra todos los presupuestos que pertenezcan a un cliente concreto")
	public List<Presupuesto> findByCliente (@PathVariable String correo, @RequestParam int pagina){
		Cliente cliente = clienteService.findByCorreo(correo);
		return presupuestoService.findPresupuestoByCliente(cliente, pagina).getContent();
	}
	
	@DeleteMapping("/deleteById/{id}")
	@Operation(summary = "Elimina un presupuesto a partir de su id")
	public void deleteById(@PathVariable Long id) {
		presupuestoService.deleteById(id);
	}
}
