package com.euroconstrucciones.webservice.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.euroconstrucciones.webservice.domain.Cliente;

public interface ClienteService {

	public List<Cliente> findAll();

	public Page<Cliente> findAll(int pagina);

	public Cliente findById(Long id);

	public Cliente save(Cliente cliente);
	
	public Cliente update(Cliente cliente);

	public void deleteById(Long id);

	boolean existsUsuarioPorCorreo(String correo);

	Cliente findByCorreo(String correo);
}
