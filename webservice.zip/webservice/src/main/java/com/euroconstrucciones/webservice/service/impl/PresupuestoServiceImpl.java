package com.euroconstrucciones.webservice.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import com.euroconstrucciones.webservice.domain.Cliente;
import com.euroconstrucciones.webservice.domain.Presupuesto;
import com.euroconstrucciones.webservice.repository.PresupuestoRepository;
import com.euroconstrucciones.webservice.service.PresupuestoService;

@Validated
@Service
public class PresupuestoServiceImpl implements PresupuestoService {
	@Autowired
	private PresupuestoRepository presupuestoRepository;
	
	@Override
	public Iterable<Presupuesto> findAll() {
		return presupuestoRepository.findAll();
	}

	@Override
	public Page<Presupuesto> findAll(int pagina) {
	    int tamano = 5;
	     
	    Pageable pageable = PageRequest.of(pagina - 1, tamano);
	     
	    return presupuestoRepository.findAll(pageable);
	}

	@Override
	public Presupuesto findById(Long id) {
		Optional<Presupuesto> presupuesto = presupuestoRepository.findById(id);
		if (presupuesto.isEmpty()) {
			return null;
		}
		return presupuesto.get();
	}
	
	@Override
	public List<Presupuesto> findByCliente (Cliente cliente) {
		List<Presupuesto> presupuestosCliente = presupuestoRepository.findByCliente(cliente);
		
		return presupuestosCliente;
	}
	
	public Page<Presupuesto> findPresupuestoByCliente(Cliente cliente, int pagina) {
		int tamano = 5;
	     
	    Pageable pageable = PageRequest.of(pagina - 1, tamano);
	    
	    return presupuestoRepository.findPresupuestoByCliente(cliente, pageable);
	}

	@Override
	public Presupuesto save(Presupuesto presupuesto) {
		return presupuestoRepository.save(presupuesto);
	}

	@Override
	public Presupuesto update(Presupuesto presupuestoUpdate) {
		return presupuestoRepository.save(presupuestoUpdate);
	}
	
	@Override
	public void deleteById(Long id) {
		presupuestoRepository.deleteById(id);
	}
}
