package com.euroconstrucciones.webservice.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.euroconstrucciones.webservice.domain.Cliente;
import com.euroconstrucciones.webservice.domain.Presupuesto;

public interface PresupuestoRepository extends JpaRepository<Presupuesto, Long>{
	List<Presupuesto> findByCliente (Cliente cliente);
	
	Page<Presupuesto> findPresupuestoByCliente(Cliente cliente, Pageable pageable);
	
	@Query("SELECT count(p) FROM Presupuesto p")
	int countAllPresupuesto();
}
