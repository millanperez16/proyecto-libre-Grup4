package com.euroconstrucciones.webservice.domain;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.euroconstrucciones.webservice.PasswordSerializer;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "clientes")
public class Cliente implements UserDetails {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Getter
	@JsonIgnore
	private long idCliente;

	@NotEmpty(message = "{validaciones.strings.NotEmpty}")
	@Getter
	@Setter
	private String nombre;

	@NotEmpty(message = "{validaciones.strings.NotEmpty}")
	@Email(message = "{validaciones.correo.Email}")
	@Column(name = "mail", nullable = false, length = 50, unique = true)
	@Getter
	@Setter
	private String correo;

	@NotEmpty(message = "{validaciones.strings.NotEmpty}")
	@Pattern(regexp = "^(\\+34|34)?[6789]\\d{8}$", message = "No es un teléfono de España")
	@Column(name = "telefono", length = 9)
	@Getter
	@Setter
	private String tlf;

	@NotEmpty(message = "{validaciones.strings.NotEmpty}")
	@Size(min = 8, message = "{validaciones.tamano.Size}")
	@Getter
	@Setter
	@JsonSerialize(using = PasswordSerializer.class)
	private String passwd;

	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "rol", referencedColumnName = "idRol")
	@Getter
	@Setter
	private Rol rol;

	@OneToMany(mappedBy = "cliente", cascade = CascadeType.ALL)
	@Getter
	@Setter
	@JsonIgnore
	private List<Presupuesto> presupuesto;

	public Cliente(long idCliente, String nombre, String correo, String tlf, String passwd) {
		super();
		this.idCliente = idCliente;
		this.nombre = nombre;
		this.correo = correo;
		this.tlf = tlf;
		this.passwd = passwd;
	}
	
	@JsonIgnore
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		List<SimpleGrantedAuthority> authorities = new ArrayList<>();
		SimpleGrantedAuthority authority = new SimpleGrantedAuthority(this.rol.getNombre());
		authorities.add(authority);
		return authorities;
	}

	@JsonIgnore
	@Override
	public String getPassword() {
		return this.getPasswd();
	}

	@JsonIgnore
	@Override
	public String getUsername() {
		return this.getCorreo();
	}

	@JsonIgnore
	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@JsonIgnore
	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@JsonIgnore
	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@JsonIgnore
	@Override
	public boolean isEnabled() {
		return true;
	}

}