package com.euroconstrucciones.webservice.domain;

import java.util.List;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "clientes")
public class Cliente {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Getter
	private long idCliente;
	
	@NotEmpty(message="{validaciones.strings.NotEmpty}")
	@Getter
	@Setter
	private String nombre;
	
	@NotEmpty(message="{validaciones.strings.NotEmpty}")
	@Email(message="{validaciones.correo.Email}")
	@Column(name="mail", nullable=false, length = 50, unique = true)
	@Getter
	@Setter
	private String correo;
	
	@NotEmpty(message="{validaciones.strings.NotEmpty}")
	@Pattern(regexp="^(\\+34|34)?[6789]\\d{8}$", message="No es un teléfono de España")
	@Column(name = "telefono", length = 9)
	@Getter
	@Setter
	private String tlf;
	
	@NotEmpty(message="{validaciones.strings.NotEmpty}")
	@Size(min=8, message="{validaciones.tamano.Size}")
	@Getter
	@Setter
	private String passwd;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "rol", referencedColumnName = "idRol")
	@Getter
	@Setter
	private Rol rol;
	
	@OneToMany(mappedBy="cliente",cascade=CascadeType.ALL)
	@Getter
	@Setter
	private List<Presupuesto> presupuesto;

	public Cliente(long id_cliente, String nombre, String correo, String tlf, String passwd) {
		super();
		this.idCliente = id_cliente;
		this.nombre = nombre;
		this.correo = correo;
		this.tlf = tlf;
		this.passwd = passwd;
	}

}