package com.euroconstrucciones.webservice.validators.groups;

public interface PresupuestoValidations {

}
