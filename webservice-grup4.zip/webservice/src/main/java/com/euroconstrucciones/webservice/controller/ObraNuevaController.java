package com.euroconstrucciones.webservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.euroconstrucciones.webservice.domain.ObraNueva;
import com.euroconstrucciones.webservice.service.ObraNuevaService;
import com.euroconstrucciones.webservice.validators.groups.ObraNuevaValidations;
import com.euroconstrucciones.webservice.validators.groups.PresupuestoValidations;

import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "ObraNueva", description = "ObraNuevaController API")
@RestController
@RequestMapping("/presupuestos/obranueva")
public class ObraNuevaController {

	@Autowired
	private ObraNuevaService obraNuevaService;

	@GetMapping("/findAllObra")
	public List<ObraNueva> findAllObra(@RequestParam int pagina) {
		return obraNuevaService.findAll(pagina).getContent();
	}

	@PostMapping("/saveObra")
	public ObraNueva saveObra(
			@RequestBody @Validated({ ObraNuevaValidations.class, PresupuestoValidations.class }) ObraNueva obranueva) {
		return obraNuevaService.save(obranueva);
	}
	
	@PutMapping("/updateObra")
	public ObraNueva updateObra(
			@RequestBody @Validated({ ObraNuevaValidations.class, PresupuestoValidations.class }) ObraNueva obranueva) {
		return obraNuevaService.update(obranueva);
	}
}
