package com.euroconstrucciones.webservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.euroconstrucciones.webservice.domain.Presupuesto;
import com.euroconstrucciones.webservice.service.PresupuestoService;

import io.swagger.v3.oas.annotations.tags.Tag;

/* Swagger */
@Tag(name = "Presupuesto", description = "PresupuestoController API")
@RestController
@RequestMapping("/presupuestos")
public class PresupuestoController {
	
	@Autowired
	private PresupuestoService presupuestoService;

	@GetMapping("/findAll")
	public List<Presupuesto> findAll (@RequestParam int pagina) {
		return presupuestoService.findAll(pagina).getContent();
	}
	
	@GetMapping("/findById/{id}")
	public Presupuesto findById(@PathVariable Long id) {
		return presupuestoService.findById(id);
	}
	
}
