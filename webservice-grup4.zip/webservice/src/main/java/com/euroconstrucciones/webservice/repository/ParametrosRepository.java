package com.euroconstrucciones.webservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.euroconstrucciones.webservice.domain.Parametros;

public interface ParametrosRepository extends JpaRepository<Parametros, Long>{

}
