package com.euroconstrucciones.webservice.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import com.euroconstrucciones.webservice.domain.Aseos;
import com.euroconstrucciones.webservice.repository.AseosRepository;
import com.euroconstrucciones.webservice.service.AseosService;

@Validated
@Service
public class AseosServiceImpl implements AseosService {

	@Autowired
	private AseosRepository aseosRepository;
	
	@Override
	public Iterable<Aseos> findAll() {
		return aseosRepository.findAll();
	}

	@Override
	public Page<Aseos> findAll(Pageable pageable) {
		return aseosRepository.findAll(pageable);
	}

	@Override
	public Aseos findById(Long id) {
		Optional<Aseos> aseos = aseosRepository.findById(id);
		if (aseos.isEmpty()) {
			return null;
		}
		return aseos.get();
	}

	@Override
	public Aseos save(Aseos aseos) {
		return aseosRepository.save(aseos);
	}
	
	@Override
	public Aseos update(Aseos aseosUpdate) {
		Optional<Aseos> updateAseos = aseosRepository.findById(aseosUpdate.getIdPresupuesto());
		Aseos reforma = updateAseos.get();
		return aseosRepository.save(reforma);
	}

	@Override
	public void deleteById(Long id) {
		aseosRepository.deleteById(id);
	}
}
