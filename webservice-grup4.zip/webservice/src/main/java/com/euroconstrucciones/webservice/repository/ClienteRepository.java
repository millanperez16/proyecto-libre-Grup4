package com.euroconstrucciones.webservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.euroconstrucciones.webservice.domain.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Long>{
	
	boolean existsByCorreo(String correo);

    Cliente findByCorreo(String correo);

}
