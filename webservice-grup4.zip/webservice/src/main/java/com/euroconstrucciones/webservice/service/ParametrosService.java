package com.euroconstrucciones.webservice.service;

import com.euroconstrucciones.webservice.domain.Parametros;

public interface ParametrosService {
	public void inicializarParametros();

	public void save(Parametros parametros);
}
