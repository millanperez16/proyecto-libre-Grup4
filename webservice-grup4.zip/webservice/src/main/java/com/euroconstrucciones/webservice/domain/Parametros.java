package com.euroconstrucciones.webservice.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;

@Entity
public class Parametros {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Getter
	private long id;
	
	public static final String PREFIJO_OBRA = "OBN";
	public static final String PREFIJO_REFORMA = "RE";
	public static final String SUFIJO_ASEO = "A";
	public static final String SUFIJO_COCINA = "CO";
	public static final int PRECIO_M2_OBRA = 1100;
	public static final int MANO_DE_OBRA_REFORMA = 50;
	public static final int PRECIO_M2_REFORMA = 35;
	public static final double IVA = 1.21;
}
