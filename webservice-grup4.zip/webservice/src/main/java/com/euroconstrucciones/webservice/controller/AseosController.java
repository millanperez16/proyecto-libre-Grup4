package com.euroconstrucciones.webservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.euroconstrucciones.webservice.domain.Aseos;
import com.euroconstrucciones.webservice.service.AseosService;
import com.euroconstrucciones.webservice.validators.groups.AseosValidations;
import com.euroconstrucciones.webservice.validators.groups.PresupuestoValidations;

import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Aseos", description = "AseosController API")
@RestController
@RequestMapping("/presupuestos/aseos")
public class AseosController {
	
	@Autowired
	private AseosService aseosService;
	
	@GetMapping("/findAllRefAseos")
	public List<Aseos> findAllRefAseos(@RequestParam int pagina) {
		return aseosService.findAll(pagina).getContent();
	}
	
	@PostMapping("/saveRefAseo")
	public Aseos saveRefAseo(
			@RequestBody @Validated({ AseosValidations.class, PresupuestoValidations.class }) Aseos aseo) {
		return aseosService.save(aseo);
	}
	
	@PutMapping("/updateRefAseo")
	public Aseos updateRefAseo(
			@RequestBody @Validated({ AseosValidations.class, PresupuestoValidations.class }) Aseos aseo) {
		return aseosService.update(aseo);
	}
	
}
