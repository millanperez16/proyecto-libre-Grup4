package com.euroconstrucciones.webservice.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.euroconstrucciones.webservice.domain.Parametros;
import com.euroconstrucciones.webservice.repository.ParametrosRepository;
import com.euroconstrucciones.webservice.service.ParametrosService;

@Service
public class ParametrosServiceImpl implements ParametrosService {
    
    @Autowired
    private ParametrosRepository parametrosRepository;
    
    public void inicializarParametros() {
        // Verificar si los parámetros ya existen en la base de datos
        if (parametrosRepository.count() == 0) {
            // Crear nuevos objetos de parámetros y guardarlos en la base de datos
            Parametros parametros = new Parametros();
            parametros.setPrefijoObra("OBN");
            parametros.setPrefijoReforma("RE");
            parametros.setSufijoAseo("A");
            parametros.setSufijoCocina("CO");
            parametros.setPrecioM2Obra(1100);
            parametros.setManoDeObraReforma(50);
            parametros.setPrecioM2Reforma(35);
            parametros.setIVA(1.21);
            parametrosRepository.save(parametros);
        }
    }

	@Override
	public void save(Parametros parametros) {
		parametrosRepository.save(parametros);
		
	}
    
}