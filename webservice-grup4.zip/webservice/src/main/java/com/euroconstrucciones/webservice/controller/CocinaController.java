package com.euroconstrucciones.webservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.euroconstrucciones.webservice.domain.Cocina;
import com.euroconstrucciones.webservice.service.CocinaService;

import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Cocina", description = "CocinaController API")
@RestController
@RequestMapping("/presupuestos/cocina")
public class CocinaController {
	@Autowired
	private CocinaService cocinaService;
	
	@GetMapping("/findAllRefCocina")
	public List<Cocina> findAllRefCocina(@RequestParam int pagina) {
		return cocinaService.findAll(pagina).getContent();
	}
}
