package com.euroconstrucciones.webservice.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import com.euroconstrucciones.webservice.domain.Cocina;
import com.euroconstrucciones.webservice.repository.CocinaRepository;
import com.euroconstrucciones.webservice.service.CocinaService;

@Validated
@Service
public class CocinaServiceImpl implements CocinaService {

	@Autowired
	private CocinaRepository cocinaRepository;
	
	@Override
	public Iterable<Cocina> findAll() {
		return cocinaRepository.findAll();
	}

	@Override
	public Page<Cocina> findAll(Pageable pageable) {
		return cocinaRepository.findAll(pageable);
	}

	@Override
	public Cocina findById(Long id) {
		Optional<Cocina> cocina = cocinaRepository.findById(id);
		if (cocina.isEmpty()) {
			return null;
		}
		return cocina.get();
	}

	@Override
	public Cocina save(Cocina cocina) {
		return cocinaRepository.save(cocina);
	}
	
	@Override
	public Cocina update(Cocina cocinaUpdate) {
		Optional<Cocina> updateAseos = cocinaRepository.findById(cocinaUpdate.getIdPresupuesto());
		Cocina reforma = updateAseos.get();
		return cocinaRepository.save(reforma);
	}

	@Override
	public void deleteById(Long id) {
		cocinaRepository.deleteById(id);
	}
}
