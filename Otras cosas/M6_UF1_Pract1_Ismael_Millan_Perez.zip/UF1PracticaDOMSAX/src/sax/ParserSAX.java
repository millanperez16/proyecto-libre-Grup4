package sax;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import domain.Plat;

public class ParserSAX extends DefaultHandler {
	int elementActual = 0;
	private Plat platActual;
	private List<Plat> llistaPlats = new ArrayList<>();

	public List<Plat> getLlistaPlats() {
		return llistaPlats;
	}

	@Override
	public void startDocument() throws SAXException {
		System.out.println("Comencem a llegir el Document");
	}

	@Override
	public void endDocument() throws SAXException {
		System.out.println("Hem acabat de llegir el Document");
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		if (qName.equals("Plat")) {
			platActual = new Plat();
			elementActual = 1;
		} else if (qName.equals("Descripcio")) {
			if (elementActual == 1) {
				String codi = attributes.getValue("codi");
				String preu = attributes.getValue("preu");
				platActual.setCodi(codi);
				if (preu != null) {
					platActual.setPreu(Double.parseDouble(preu));
				}
				elementActual = 2;
			} else if (elementActual == 4) {
				elementActual = 5;
			}
		} else if (qName.equals("Tipus")) {
			if (elementActual == 1) {
				elementActual = 3;
			} else if (elementActual == 4) {
				elementActual = 6;
			}
		} else if (qName.equals("Grup")) {
			String codiGrup = attributes.getValue("id");
			platActual.setCodiGrup(codiGrup);
			elementActual = 4;
		}
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		String cadena = new String(ch, start, length).trim();
		if (!cadena.isEmpty()) {
			if (elementActual == 2) {
				platActual.setDescripcio(cadena);
				elementActual = 1;
			} else if (elementActual == 3) {
				platActual.setTipus(cadena);
				elementActual = 1;
			} else if (elementActual == 4) {
				platActual.setCodiGrup(cadena);
			} else if (elementActual == 5) {
				platActual.setDescripcioGrup(cadena);
				elementActual = 4;
			} else if (elementActual == 6) {
				platActual.setTipusGrup(cadena);
				elementActual = 4;
			}
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if (qName.contains("Plat")) {
			llistaPlats.add(platActual);
			elementActual = 0;
		}
	}
}
