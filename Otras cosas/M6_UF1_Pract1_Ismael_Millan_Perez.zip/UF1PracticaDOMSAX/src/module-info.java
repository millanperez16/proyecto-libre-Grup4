/**
 * 
 */
/**
 * 
 */
module UF1PracticaDOMSAX {
	requires java.xml;
}