package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

import dom.ParserDOM;
import domain.Plat;
import sax.ParserSAX;

public class LlegirPlats {

	public static void main(String[] args) throws IOException, SAXException, ParserConfigurationException {
		File fitxer = new File("MenuXML.xml");

		if (fitxer.exists()) {
			ParserDOM parser = new ParserDOM(fitxer);

			parser.generarDOM();

			String contenido = "";
			List<Plat> platos = parser.recorreryMostrarDOM();
			for (Plat plato : platos) {
				System.out.println(plato);
				contenido += plato.toString();
			}

			// Escribimos el conenido en el fichero ResumPlats.txt
			FileWriter archivoGuardar = new FileWriter("ResumPlats.txt");
			BufferedWriter writer = new BufferedWriter(archivoGuardar);
			writer.write(contenido);
			writer.close();

			// Leemos a partir del fichero generado ResumPlats.txt
			BufferedReader reader = new BufferedReader(new FileReader("ResumPlats.txt"));
			String linea;
			while ((linea = reader.readLine()) != null) {
				System.out.println(linea);
			}
			reader.close();
			
			// Añadir nuevo plato y generar nuevo XML
			Plat bacalao = new Plat("A44", "Bacallà a la llauna", 14, "Plat Principal", "2", "Origen Animal", "Peix");
			parser.afegirNode(bacalao);
			File archivoNuevoXML = new File("PlatsXML2.xml");
			parser.guardarDOMaFileTransformer(archivoNuevoXML);
			
			// Hacer lista de platos pero con SAX
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser parserSAX = factory.newSAXParser();
			ParserSAX hl= new ParserSAX();
			parserSAX.parse(fitxer, hl);
			List<Plat> platosSAX = hl.getLlistaPlats();
			for (Plat plato : platosSAX) {
				System.out.println(plato);
			}

		} else {
			System.out.println("El fichero no existe");
		}
	}

}
