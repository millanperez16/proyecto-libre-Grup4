package domain;

public class Plat {
	private String codi;
	private String descripcio;
	private double preu;
	private String tipus;
	private String codiGrup;
	private String descripcioGrup;
	private String tipusGrup;

	public Plat() {
		super();
	}

	public Plat(String codi, String descripcio, double preu, String tipus, String codiGrup, String descripcioGrup,
			String tipusGrup) {
		super();
		this.codi = codi;
		this.descripcio = descripcio;
		this.preu = preu;
		this.tipus = tipus;
		this.codiGrup = codiGrup;
		this.descripcioGrup = descripcioGrup;
		this.tipusGrup = tipusGrup;
	}

	public String getCodi() {
		return codi;
	}

	public void setCodi(String codi) {
		this.codi = codi;
	}

	public String getDescripcio() {
		return descripcio;
	}

	public void setDescripcio(String descripcio) {
		this.descripcio = descripcio;
	}

	public double getPreu() {
		return preu;
	}

	public void setPreu(double preu) {
		this.preu = preu;
	}

	public String getTipus() {
		return tipus;
	}

	public void setTipus(String tipus) {
		this.tipus = tipus;
	}

	public String getCodiGrup() {
		return codiGrup;
	}

	public void setCodiGrup(String codiGrup) {
		this.codiGrup = codiGrup;
	}

	public String getDescripcioGrup() {
		return descripcioGrup;
	}

	public void setDescripcioGrup(String descripcioGrup) {
		this.descripcioGrup = descripcioGrup;
	}

	public String getTipusGrup() {
		return tipusGrup;
	}

	public void setTipusGrup(String tipusGrup) {
		this.tipusGrup = tipusGrup;
	}

	@Override
	public String toString() {
		return "Plat: " + codi + " " + descripcio + " (" + tipus + ")\n\t Grup: " + codiGrup + " " + descripcioGrup
				+ " (" + tipusGrup + ")\n\t Preu: " + String.format("%.2f€", preu) + "\n";
	}

}
